# ============================================================
# Title:  Rendering backends of umg: grid, ggplot2, TikZ, DOT/DiagrammeR, umg_save()
# File:   demo_backends_V01.R
# Author: HTYu
# Date:   2026-08-22
# ============================================================
# Takes the sleepstudy growth diagram (umg_from_lmer) and the HS CFA
# diagram (umg_from_lavaan) and renders each with every backend:
# plot() [grid] -> PDF; umg_ggplot() -> PDF; umg_to_tikz() -> .tex;
# umg_to_dot() -> .dot (+ Graphviz 'dot' command-line rendering to PNG
# as an independent check); umg_render_dot() [DiagrammeR htmlwidget] ->
# HTML via htmlwidgets::saveWidget(); and umg_save() with every
# supported extension and both graphics backends.
# Run: Rscript R/demo_backends_V01.R
# Output: output/demo_backends_V01.txt + output/backend_* files

#----- Packages & Setup -----------------------------------------------------
library(lme4)
library(lavaan)
library(ggplot2)
library(umg)

script_dir <- local({
  a <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", a[grepl("^--file=", a)])
  if (length(f)) dirname(normalizePath(f[1])) else getwd()
})
out_dir <- normalizePath(file.path(script_dir, "..", "output"),
                         mustWork = FALSE)
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

con <- file(file.path(out_dir, "demo_backends_V01.txt"), open = "wt")
sink(con, split = TRUE)
cat("demo_backends_V01.R  --  run on", format(Sys.time()), "\n")
cat("R ", R.version$major, ".", R.version$minor,
    "; umg ", as.character(packageVersion("umg")),
    "; ggplot2 ", as.character(packageVersion("ggplot2")),
    "; DiagrammeR ", tryCatch(as.character(packageVersion("DiagrammeR")), error = function(e) "not installed"),
    "; htmlwidgets ", tryCatch(as.character(packageVersion("htmlwidgets")), error = function(e) "not installed"),
    "\n", sep = "")
cat("Graphviz 'dot' on PATH:", nzchar(Sys.which("dot")),
    if (nzchar(Sys.which("dot"))) system2("dot", "-V", stdout = TRUE, stderr = TRUE) else "", "\n\n")

report <- function(label, expr) {
  cat("\n>>> ", label, "\n", sep = "")
  withCallingHandlers(
    tryCatch(expr, error = function(e) {
      cat("    ERROR: ", conditionMessage(e), "\n", sep = ""); NULL }),
    warning = function(w) {
      cat("    WARNING: ", conditionMessage(w), "\n", sep = "")
      invokeRestart("muffleWarning") },
    message = function(m) {
      cat("    MESSAGE: ", conditionMessage(m), sep = "")
      invokeRestart("muffleMessage") })
}
fsize <- function(f) if (file.exists(f)) sprintf("%s (%d bytes)", basename(f), file.size(f)) else paste(basename(f), "MISSING")

#----- The two diagrams ------------------------------------------------------
data(sleepstudy, package = "lme4")
m_sleep <- umg_from_lmer(Reaction ~ Days + (Days | Subject), data = sleepstudy)
HS.model <- 'visual =~ x1+x2+x3; textual =~ x4+x5+x6; speed =~ x7+x8+x9'
m_hs <- umg_from_lavaan(cfa(HS.model, data = HolzingerSwineford1939))
diagrams <- list(sleepstudy = m_sleep, hs_cfa = m_hs)
for (nm in names(diagrams)) { cat("\nDiagram", nm, ":\n"); print(diagrams[[nm]]) }

#----- 1. Base grid backend: plot() ------------------------------------------
cat("\n==================================================================\n")
cat("1. plot() [grid backend] -> PDF (+ PNG), default theme and 'cb' theme\n")
cat("==================================================================\n")
for (nm in names(diagrams)) {
  f <- file.path(out_dir, paste0("backend_grid_", nm, ".pdf"))
  report(paste("plot():", basename(f)), {
    pdf(f, width = 8, height = 6)
    plot(diagrams[[nm]])
    plot(diagrams[[nm]], theme = umg_theme("cb"))
    plot(diagrams[[nm]], orientation = "LR")
    dev.off()
  })
  cat("    ", fsize(f), " (3 pages: journal, cb, LR orientation)\n", sep = "")
  fp <- file.path(out_dir, paste0("backend_grid_", nm, ".png"))
  report(paste("plot() to PNG:", basename(fp)), {
    png(fp, width = 1600, height = 1200, res = 200); plot(diagrams[[nm]]); dev.off()
  })
  cat("    ", fsize(fp), "\n", sep = "")
}

#----- 2. ggplot2 backend: umg_ggplot() / autoplot() -------------------------
cat("\n==================================================================\n")
cat("2. umg_ggplot() / autoplot() [ggplot2 backend] -> PDF (+ PNG)\n")
cat("==================================================================\n")
for (nm in names(diagrams)) {
  g <- report(paste0("umg_ggplot(", nm, ")"), umg_ggplot(diagrams[[nm]]))
  cat("    class:", paste(class(g), collapse = "/"), "\n")
  f <- file.path(out_dir, paste0("backend_ggplot_", nm, ".pdf"))
  report(paste("ggsave:", basename(f)), ggsave(f, g, width = 8, height = 6))
  cat("    ", fsize(f), "\n", sep = "")
  fp <- file.path(out_dir, paste0("backend_ggplot_", nm, ".png"))
  report(paste("ggsave:", basename(fp)), ggsave(fp, g, width = 8, height = 6, dpi = 200))
  cat("    ", fsize(fp), "\n", sep = "")
  ga <- report(paste0("autoplot(", nm, ")"), autoplot(diagrams[[nm]]))
  cat("    autoplot class:", paste(class(ga), collapse = "/"), "\n")
}

#----- 3. TikZ export --------------------------------------------------------
cat("\n==================================================================\n")
cat("3. umg_to_tikz() -> .tex\n")
cat("==================================================================\n")
for (nm in names(diagrams)) {
  f <- file.path(out_dir, paste0("backend_tikz_", nm, ".tex"))
  code <- report(paste("umg_to_tikz(file =", basename(f), ")"),
                 umg_to_tikz(diagrams[[nm]], file = f))
  cat("    ", fsize(f), "; ", length(readLines(f)), " lines\n", sep = "")
  cat("    first lines:\n"); cat(paste0("      ", head(readLines(f), 8)), sep = "\n")
}
cat("\nThe TikZ dialect file shipped with the package:",
    system.file("tikz", "umg-style.tex", package = "umg"), "\n")
cat("(A LaTeX compile is not attempted here; the .tex files are the deliverable.)\n")

#----- 4. DOT export and Graphviz rendering ----------------------------------
cat("\n==================================================================\n")
cat("4. umg_to_dot() -> .dot; independent rendering with the Graphviz CLI\n")
cat("==================================================================\n")
for (nm in names(diagrams)) {
  f <- file.path(out_dir, paste0("backend_dot_", nm, ".dot"))
  dot <- report(paste("umg_to_dot(file =", basename(f), ")"),
                umg_to_dot(diagrams[[nm]], file = f))
  cat("    ", fsize(f), "; ", length(readLines(f)), " lines\n", sep = "")
  cat("    DOT code:\n"); cat(paste0("      ", readLines(f)), sep = "\n")
  if (nzchar(Sys.which("dot"))) {
    fp <- file.path(out_dir, paste0("backend_dot_", nm, "_graphviz.png"))
    st <- system2("dot", c("-Tpng", shQuote(f), "-o", shQuote(fp)), stdout = TRUE, stderr = TRUE)
    cat("    Graphviz CLI render: exit status",
        if (is.null(attr(st, "status"))) 0 else attr(st, "status"),
        if (length(st)) paste("; output:", paste(st, collapse = " ")) else "",
        "->", fsize(fp), "\n")
  }
}

#----- 5. DiagrammeR rendering (headless) ------------------------------------
cat("\n==================================================================\n")
cat("5. umg_render_dot() [DiagrammeR::grViz htmlwidget] -> HTML via htmlwidgets::saveWidget()\n")
cat("==================================================================\n")
if (requireNamespace("DiagrammeR", quietly = TRUE) &&
    requireNamespace("htmlwidgets", quietly = TRUE)) {
  for (nm in names(diagrams)) {
    w <- report(paste0("umg_render_dot(", nm, ")"), umg_render_dot(diagrams[[nm]]))
    cat("    class:", paste(class(w), collapse = "/"), "\n")
    f <- file.path(out_dir, paste0("backend_diagrammer_", nm, ".html"))
    report(paste("saveWidget:", basename(f)),
           htmlwidgets::saveWidget(w, file = f, selfcontained = FALSE,
                                   libdir = file.path(out_dir, "backend_diagrammer_lib")))
    cat("    ", fsize(f), " (JS dependencies in output/backend_diagrammer_lib/)\n", sep = "")
    if (requireNamespace("DiagrammeRsvg", quietly = TRUE)) {
      svg <- report(paste0("DiagrammeRsvg::export_svg(widget) [requires V8]"),
                    DiagrammeRsvg::export_svg(w))
      if (!is.null(svg)) {
        fs <- file.path(out_dir, paste0("backend_diagrammer_", nm, ".svg"))
        writeLines(svg, fs)
        cat("    ", fsize(fs), "\n", sep = "")
      }
    }
  }
} else {
  cat("DiagrammeR and/or htmlwidgets not installed: umg_render_dot() skipped.\n")
}

#----- 6. umg_save() with every extension ------------------------------------
cat("\n==================================================================\n")
cat("6. umg_save() dispatch on extension (grid and ggplot backends)\n")
cat("==================================================================\n")
exts <- c("pdf", "png", "svg", "tex", "tikz", "dot", "gv")
for (nm in names(diagrams)) {
  for (ext in exts) {
    f <- file.path(out_dir, paste0("backend_save_", nm, ".", ext))
    report(paste0("umg_save(m, '", basename(f), "')"), umg_save(diagrams[[nm]], f))
    cat("    ", fsize(f), "\n", sep = "")
  }
  for (ext in c("pdf", "png", "svg")) {
    f <- file.path(out_dir, paste0("backend_save_ggplot_", nm, ".", ext))
    report(paste0("umg_save(m, '", basename(f), "', backend = 'ggplot')"),
           umg_save(diagrams[[nm]], f, backend = "ggplot"))
    cat("    ", fsize(f), "\n", sep = "")
  }
}
report("umg_save() with an unsupported extension (.jpg) -> expected error",
       umg_save(m_hs, file.path(out_dir, "backend_save_unsupported.jpg")))
report("umg_save() with an invalid theme -> expected error",
       umg_save(m_hs, file.path(out_dir, "backend_save_badtheme.pdf"), theme = 42))
if (file.exists(file.path(out_dir, "backend_save_badtheme.pdf")))
  file.remove(file.path(out_dir, "backend_save_badtheme.pdf"))

#----- 7. Theme variants and user-supplied coordinates -----------------------
cat("\n==================================================================\n")
cat("7. Themes ('journal', 'slide', 'cb') and umg_layout(coords = ...)\n")
cat("==================================================================\n")
f <- file.path(out_dir, "backend_themes_hs_cfa.pdf")
report("three themes on the HS CFA", {
  pdf(f, width = 8, height = 6)
  for (th in c("journal", "slide", "cb")) plot(m_hs, theme = th)
  dev.off()
})
cat("    ", fsize(f), " (3 pages)\n", sep = "")
lay <- umg_layout(m_hs)
cat("Automatic layout coordinates (umg_layout):\n"); print(lay$layout$vertices)
coords <- data.frame(name = c("visual", "textual", "speed"), x = c(-4.8, 0, 4.8), y = c(0, 0, 0))
m_hs_custom <- umg_layout(m_hs, coords = coords)
f2 <- file.path(out_dir, "backend_customlayout_hs_cfa.pdf")
report("custom factor coordinates", { pdf(f2, width = 8, height = 6); plot(m_hs_custom); dev.off() })
cat("    ", fsize(f2), "\n", sep = "")

cat("\nAll backend files in", out_dir, ":\n")
print(sort(list.files(out_dir, pattern = "^backend_")))
cat("\nDone:", format(Sys.time()), "\n")
sink()
close(con)

# ============================================================
# Title:  Diagram differencing for preregistration: preregistered vs. final
#         measurement model compared as typed edge sets
# File:   demo_diff_V01.R
# Author: HTYu
# Date:   2026-08-22
# ============================================================
#----- Packages & Setup -----------------------------------------------------
# umg 0.5.0 exposes a diagram's vertices and edges as data frames; a
# preregistered diagram and its estimated successor can therefore be
# differenced with ordinary set operations, no new machinery required.
suppressPackageStartupMessages({library(umg); library(lavaan)})
sink("output/demo_diff_V01.txt", split = TRUE)
cat("demo_diff_V01.R -- run on", format(Sys.time()), "\n")
cat("R", paste(R.version$major, R.version$minor, sep = "."), "; umg", as.character(packageVersion("umg")), "; lavaan", as.character(packageVersion("lavaan")), "\n\n")

#----- Two diagrams --------------------------------------------------------
# Preregistered: the classic three-factor Holzinger-Swineford structure.
# Final: the same structure plus one cross-loading (x9 on visual), the
# modification most often reported for this data set after inspection of
# modification indices.
prereg <- 'visual =~ x1 + x2 + x3
           textual =~ x4 + x5 + x6
           speed =~ x7 + x8 + x9'
final  <- 'visual =~ x1 + x2 + x3 + x9
           textual =~ x4 + x5 + x6
           speed =~ x7 + x8 + x9'
fit_pre <- cfa(prereg, data = HolzingerSwineford1939)
fit_fin <- cfa(final,  data = HolzingerSwineford1939)
m_pre <- umg_from_lavaan(fit_pre)
m_fin <- umg_from_lavaan(fit_fin)

#----- Difference as typed edge sets -----------------------------------------
edge_key <- function(m) {
  e <- as.data.frame(m, what = "edges")
  paste(e$from, e$kind, e$to)
}
k_pre <- edge_key(m_pre); k_fin <- edge_key(m_fin)
cat("Edges in the preregistered diagram:", length(k_pre), "\n")
cat("Edges in the final diagram:        ", length(k_fin), "\n\n")
cat("Added in the final diagram (not preregistered):\n")
print(setdiff(k_fin, k_pre))
cat("\nRemoved relative to the preregistered diagram:\n")
print(setdiff(k_pre, k_fin))
cat("\nVertex sets identical:", setequal(as.data.frame(m_pre)$name, as.data.frame(m_fin)$name), "\n")

#----- Consequence for the fitted models --------------------------------------
fm <- function(f) round(fitMeasures(f, c("npar", "df", "chisq", "cfi", "rmsea", "srmr")), 3)
cat("\nFit, preregistered:\n"); print(fm(fit_pre))
cat("Fit, final:\n");          print(fm(fit_fin))
cat("\nCounting rule read from each diagram:\n")
cat("  preregistered: df =", umg_count_parameters(m_pre)$df, "; final: df =", umg_count_parameters(m_fin)$df, "\n")
sink()

# ============================================================
# Title:  d-separation and implied conditional independencies (umg vs dagitty)
# File:   demo_dsep_V01.R
# Author: HTYu
# Date:   2026-08-22
# ============================================================
# Builds the mediation diagram X -> M -> Y with a direct path X -> Y:
# version A without a confounder and version B with a latent confounder
# U -> M, U -> Y (plus version A0 without the direct path, where a
# non-trivial separation exists). For each diagram the script runs
# umg_dsep() and umg_implied_ci() (observed_only TRUE and FALSE), then
# builds the same DAGs in dagitty and prints
# impliedConditionalIndependencies() and dseparated() verdicts, and
# states whether umg and dagitty agree on the DAG part.
# Run: Rscript R/demo_dsep_V01.R
# Output: output/demo_dsep_V01.txt, output/fig_dsep_mediation_V01.pdf/.png

#----- Packages & Setup -----------------------------------------------------
library(umg)
library(dagitty)

script_dir <- local({
  a <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", a[grepl("^--file=", a)])
  if (length(f)) dirname(normalizePath(f[1])) else getwd()
})
out_dir <- normalizePath(file.path(script_dir, "..", "output"),
                         mustWork = FALSE)
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

con <- file(file.path(out_dir, "demo_dsep_V01.txt"), open = "wt")
sink(con, split = TRUE)
cat("demo_dsep_V01.R  --  run on", format(Sys.time()), "\n")
cat("R ", R.version$major, ".", R.version$minor,
    "; umg ", as.character(packageVersion("umg")),
    "; dagitty ", as.character(packageVersion("dagitty")), "\n\n", sep = "")

report <- function(label, expr) {
  cat("\n>>> ", label, "\n", sep = "")
  withCallingHandlers(
    tryCatch(expr, error = function(e) {
      cat("    ERROR: ", conditionMessage(e), "\n", sep = ""); NULL }),
    warning = function(w) {
      cat("    WARNING: ", conditionMessage(w), "\n", sep = "")
      invokeRestart("muffleWarning") },
    message = function(m) {
      cat("    MESSAGE: ", conditionMessage(m), sep = "")
      invokeRestart("muffleMessage") })
}

# umg side: all queries for one diagram
umg_side <- function(m, name) {
  cat("\n------------------------------------------------------------\n")
  cat("umg diagram:", name, "\n")
  cat("------------------------------------------------------------\n")
  print(m)
  print(as.data.frame(m))
  r <- list()
  r$dsep_XY_M <- report('umg_dsep(m, "X", "Y", given = "M")', umg_dsep(m, "X", "Y", given = "M"))
  cat("    ->", r$dsep_XY_M, "\n")
  r$dsep_XY   <- report('umg_dsep(m, "X", "Y")', umg_dsep(m, "X", "Y"))
  cat("    ->", r$dsep_XY, "\n")
  if ("U" %in% names(m$nodes)) {
    r$dsep_XU <- report('umg_dsep(m, "X", "U")', umg_dsep(m, "X", "U"))
    cat("    ->", r$dsep_XU, "\n")
    r$dsep_XU_M <- report('umg_dsep(m, "X", "U", given = "M")', umg_dsep(m, "X", "U", given = "M"))
    cat("    ->", r$dsep_XU_M, " (M is a collider on X -> M <- U: conditioning opens the path)\n")
  }
  r$ci_obs <- report("umg_implied_ci(m, observed_only = TRUE)",
                     umg_implied_ci(m, observed_only = TRUE))
  cat("    -> n =", nrow(r$ci_obs), "\n"); if (nrow(r$ci_obs)) print(r$ci_obs, row.names = FALSE)
  r$ci_all <- report("umg_implied_ci(m, observed_only = FALSE)",
                     umg_implied_ci(m, observed_only = FALSE))
  cat("    -> n =", nrow(r$ci_all), "\n"); if (nrow(r$ci_all)) print(r$ci_all, row.names = FALSE)
  invisible(r)
}

# dagitty side
dag_side <- function(g, name) {
  cat("\n------------------------------------------------------------\n")
  cat("dagitty DAG:", name, "\n")
  cat("------------------------------------------------------------\n")
  print(g)
  r <- list()
  cat("\n>>> impliedConditionalIndependencies(g)\n")
  r$ci <- impliedConditionalIndependencies(g)
  if (length(r$ci)) print(r$ci) else cat("    (none)\n")
  cat("\n>>> impliedConditionalIndependencies(g, type = 'all.pairs')\n")
  r$ci_all <- tryCatch(impliedConditionalIndependencies(g, type = "all.pairs"),
                       error = function(e) { cat("    ERROR:", conditionMessage(e), "\n"); NULL })
  if (length(r$ci_all)) print(r$ci_all) else cat("    (none)\n")
  cat('\n>>> dseparated(g, "X", "Y", "M")\n')
  r$dsep_XY_M <- dseparated(g, "X", "Y", "M"); cat("    ->", r$dsep_XY_M, "\n")
  cat('\n>>> dseparated(g, "X", "Y")\n')
  r$dsep_XY <- dseparated(g, "X", "Y"); cat("    ->", r$dsep_XY, "\n")
  if ("U" %in% names(g)) {
    cat('\n>>> dseparated(g, "X", "U")\n')
    r$dsep_XU <- dseparated(g, "X", "U"); cat("    ->", r$dsep_XU, "\n")
    cat('\n>>> dseparated(g, "X", "U", "M")\n')
    r$dsep_XU_M <- dseparated(g, "X", "U", "M"); cat("    ->", r$dsep_XU_M, "\n")
  }
  cat("\n>>> adjustmentSets(g, exposure = 'X', outcome = 'Y') [dagitty only; causal reading]\n")
  print(adjustmentSets(g, exposure = "X", outcome = "Y"))
  invisible(r)
}

agree <- function(a, b, what) {
  ok <- identical(as.logical(a), as.logical(b))
  cat(sprintf("  %-28s umg = %-5s dagitty = %-5s -> %s\n", what, a, b,
              if (ok) "AGREE" else "DISAGREE"))
  ok
}

# umg_implied_ci() returns one row per (vertex, non-descendant) pair under
# the local Markov property, so a symmetric statement such as X _||_ U can
# appear twice (as X,U and as U,X). Reduce to unordered pairs for comparison.
ci_pairs <- function(ci) {
  if (!nrow(ci)) return(character(0))
  unique(paste(pmin(ci$x, ci$y), pmax(ci$x, ci$y), ci$given, sep = "|"))
}

#----- Version A: X -> M -> Y, X -> Y, no confounder --------------------------
cat("==================================================================\n")
cat("Version A: X -> M -> Y with direct path X -> Y, no confounder\n")
cat("==================================================================\n")
mA <- umg_mediation(direct = TRUE, confounder = FALSE, badge = "structural")
rA <- umg_side(mA, "umg_mediation(direct = TRUE, confounder = FALSE)")
gA <- dagitty("dag{X->M->Y; X->Y}")
dA <- dag_side(gA, 'dagitty("dag{X->M->Y; X->Y}")')
cat("\nAgreement, version A:\n")
okA <- c(agree(rA$dsep_XY_M, dA$dsep_XY_M, "X _||_ Y | M"),
         agree(rA$dsep_XY, dA$dsep_XY, "X _||_ Y"),
         agree(nrow(rA$ci_obs) == 0, length(dA$ci) == 0, "no implied CIs"))

#----- Version B: latent confounder U -> M, U -> Y ---------------------------
cat("\n==================================================================\n")
cat("Version B: X -> M -> Y, X -> Y, latent confounder U -> M, U -> Y\n")
cat("==================================================================\n")
mB <- umg_mediation(direct = TRUE, confounder = TRUE, badge = "structural")
rB <- umg_side(mB, "umg_mediation(direct = TRUE, confounder = TRUE)")
gB <- dagitty("dag{X->M->Y; X->Y; U->M; U->Y}")
dB <- dag_side(gB, 'dagitty("dag{X->M->Y; X->Y; U->M; U->Y}")  [U not declared latent]')
gB_lat <- dagitty("dag{U [latent]; X->M->Y; X->Y; U->M; U->Y}")
dB_lat <- dag_side(gB_lat, 'dagitty("dag{U [latent]; X->M->Y; X->Y; U->M; U->Y}")  [U declared latent]')
cat("\nAgreement, version B (U not latent in dagitty; compare with umg observed_only = FALSE):\n")
okB <- c(agree(rB$dsep_XY_M, dB$dsep_XY_M, "X _||_ Y | M"),
         agree(rB$dsep_XY, dB$dsep_XY, "X _||_ Y"),
         agree(rB$dsep_XU, dB$dsep_XU, "X _||_ U"),
         agree(rB$dsep_XU_M, dB$dsep_XU_M, "X _||_ U | M"),
         agree(identical(ci_pairs(rB$ci_all), "U|X|"),
               length(dB$ci) == 1 && setequal(c(dB$ci[[1]]$X, dB$ci[[1]]$Y), c("U", "X")) &&
                 length(dB$ci[[1]]$Z) == 0,
               "single implied CI is U _||_ X"))
cat(sprintf("  (umg_implied_ci(observed_only = FALSE) returned %d rows for %d unordered statement(s):\n   %s)\n",
            nrow(rB$ci_all), length(ci_pairs(rB$ci_all)),
            paste(ci_pairs(rB$ci_all), collapse = "; ")))
cat("\nAgreement, version B (U latent in dagitty; compare with umg observed_only = TRUE):\n")
okB2 <- c(agree(nrow(rB$ci_obs) == 0, length(dB_lat$ci) == 0,
                "no testable (observed) CI"))

#----- Version A0: no direct path (a non-trivial separation exists) ----------
cat("\n==================================================================\n")
cat("Version A0 (supplementary): X -> M -> Y without the direct path\n")
cat("==================================================================\n")
mA0 <- umg_mediation(direct = FALSE, confounder = FALSE)
rA0 <- umg_side(mA0, "umg_mediation(direct = FALSE)")
gA0 <- dagitty("dag{X->M->Y}")
dA0 <- dag_side(gA0, 'dagitty("dag{X->M->Y}")')
cat("\nAgreement, version A0:\n")
okA0 <- c(agree(rA0$dsep_XY_M, dA0$dsep_XY_M, "X _||_ Y | M"),
          agree(rA0$dsep_XY, dA0$dsep_XY, "X _||_ Y"),
          agree(nrow(rA0$ci_obs) == 1 && rA0$ci_obs$given[1] == "M",
                length(dA0$ci) == 1 && identical(dA0$ci[[1]]$Z, "M"),
                "implied CI: X _||_ Y | M"))

cat("\n==================================================================\n")
cat("Overall: umg and dagitty agree on every DAG-level verdict tested:",
    all(c(okA, okB, okB2, okA0)), "\n")
cat("==================================================================\n")
cat("\nNote on the license badge: the umg diagrams above carry badge =",
    "'structural'\n(the causal reading); umg_mediation(badge = 'statistical') produces the same\n",
    "graph with the associational badge. dagitty has no such switch: a dagitty DAG\n",
    "is causal by construction (adjustmentSets() is always available).\n")
mA_stat <- umg_mediation(direct = TRUE, confounder = FALSE, badge = "statistical")
cat("umg badge of the statistical version:", mA_stat$badge,
    "| structural version:", mA$badge, "\n")
cat("d-separation verdicts are badge-independent (graph property):",
    identical(umg_dsep(mA_stat, "X", "Y", given = "M"), umg_dsep(mA, "X", "Y", given = "M")), "\n")

#----- Figure: the two mediation diagrams under both badges -----------------
pdf(file.path(out_dir, "fig_dsep_mediation_V01.pdf"), width = 10, height = 4)
plot(mA_stat); plot(mB)
dev.off()
png(file.path(out_dir, "fig_dsep_mediation_V01.png"), width = 1800, height = 800, res = 200)
plot(mB)
dev.off()
cat("\nFigures written: fig_dsep_mediation_V01.pdf (2 pages: A statistical, B structural),",
    "fig_dsep_mediation_V01.png (B)\n")

cat("\nDone:", format(Sys.time()), "\n")
sink()
close(con)

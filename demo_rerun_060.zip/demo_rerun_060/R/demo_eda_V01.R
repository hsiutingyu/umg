# ============================================================
# Title:  Model-data duality: EDA scaffolds generated from UMG diagrams
# File:   demo_eda_V01.R
# Author: HTYu
# Date:   2026-08-22
# ============================================================
# (1) sleepstudy: umg_from_lmer(Reaction ~ Days + (Days | Subject)) and
#     umg_eda_scaffold(m, sleepstudy, id = "Subject", time = "Days");
#     every returned display is saved as PDF and PNG (eda_<motif>.*);
# (2) umg_caterpillar() on the lmer random effects (conditional modes
#     with conditional SDs);
# (3) the HS CFA diagram with HolzingerSwineford1939 (latent-score
#     distributions, observed correlation heat map).
# Run: Rscript R/demo_eda_V01.R
# Output: output/demo_eda_V01.txt + output/eda_*.pdf/png

#----- Packages & Setup -----------------------------------------------------
library(lme4)
library(lavaan)
library(ggplot2)
library(umg)
set.seed(20260822)

script_dir <- local({
  a <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", a[grepl("^--file=", a)])
  if (length(f)) dirname(normalizePath(f[1])) else getwd()
})
out_dir <- normalizePath(file.path(script_dir, "..", "output"),
                         mustWork = FALSE)
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

con <- file(file.path(out_dir, "demo_eda_V01.txt"), open = "wt")
sink(con, split = TRUE)
cat("demo_eda_V01.R  --  run on", format(Sys.time()), "\n")
cat("R ", R.version$major, ".", R.version$minor,
    "; lme4 ", as.character(packageVersion("lme4")),
    "; lavaan ", as.character(packageVersion("lavaan")),
    "; ggplot2 ", as.character(packageVersion("ggplot2")),
    "; umg ", as.character(packageVersion("umg")), "\n\n", sep = "")

report <- function(label, expr) {
  cat("\n>>> ", label, "\n", sep = "")
  withCallingHandlers(
    tryCatch(expr, error = function(e) {
      cat("    ERROR: ", conditionMessage(e), "\n", sep = ""); NULL }),
    warning = function(w) {
      cat("    WARNING: ", conditionMessage(w), "\n", sep = "")
      invokeRestart("muffleWarning") },
    message = function(m) {
      cat("    MESSAGE: ", conditionMessage(m), sep = "")
      invokeRestart("muffleMessage") })
}

# Save a ggplot (or any printable plot object) to PDF and PNG.
save_both <- function(p, stem, width = 7, height = 5) {
  pdf_file <- file.path(out_dir, paste0(stem, ".pdf"))
  png_file <- file.path(out_dir, paste0(stem, ".png"))
  ok <- report(paste0("save ", basename(pdf_file), " / .png"), {
    ggsave(pdf_file, plot = p, width = width, height = height)
    ggsave(png_file, plot = p, width = width, height = height, dpi = 200)
    TRUE
  })
  if (isTRUE(ok)) cat("    written:", basename(pdf_file), basename(png_file), "\n")
  invisible(ok)
}

#----- (1) sleepstudy growth diagram and its EDA scaffolds -------------------
cat("==================================================================\n")
cat("(1) sleepstudy: umg_from_lmer() + umg_eda_scaffold()\n")
cat("==================================================================\n")
data(sleepstudy, package = "lme4")
cat("Signature of umg_from_lmer():\n"); print(args(umg_from_lmer))
cat("Signature of umg_eda_scaffold():\n"); print(args(umg_eda_scaffold))
cat("Signature of umg_caterpillar():\n"); print(args(umg_caterpillar))

m_sleep <- report("umg_from_lmer(Reaction ~ Days + (Days | Subject), data = sleepstudy)",
                  umg_from_lmer(Reaction ~ Days + (Days | Subject), data = sleepstudy))
print(m_sleep)
cat("\nVertices:\n"); print(as.data.frame(m_sleep, what = "vertices")[, c("name", "label", "observed", "role", "dist")])
cat("\nEdges:\n");    print(as.data.frame(m_sleep))
cat("\nPlates:\n")
for (p in m_sleep$plates)
  cat(sprintf("  %-9s index = '%s'  parent = %s  members = %s\n", p$name, p$index,
              if (is.null(p$parent)) "none" else p$parent, paste(p$members, collapse = ", ")))

sc <- report('umg_eda_scaffold(m_sleep, data = sleepstudy, id = "Subject", time = "Days")',
             umg_eda_scaffold(m_sleep, data = sleepstudy, id = "Subject", time = "Days"))
cat("\nReturned object: class =", class(sc), "; length =", length(sc), "\n")
cat("Names (one display per motif):", paste(names(sc), collapse = ", "), "\n")
for (nm in names(sc)) {
  cat(sprintf("  $%s: class = %s; layers = %s\n", nm,
              paste(class(sc[[nm]]), collapse = "/"),
              paste(vapply(sc[[nm]]$layers, function(l) class(l$geom)[1], character(1)),
                    collapse = ", ")))
}
for (nm in names(sc)) save_both(sc[[nm]], paste0("eda_", nm, "_sleepstudy"))

cat("\nWhat the scaffold did NOT produce for this diagram, and why (from the source):\n",
    "  - score_<latent>: needs >= 2 observed children of a latent vertex (b0, b1 have one: Reaction);\n",
    "  - mixture_density: needs a latent categorical vertex;\n",
    "  - response_*: needs an observed categorical child;\n",
    "  - resid_heatmap: needs >= 3 observed vertices in the data (here: Reaction, Days).\n", sep = "")

#----- (2) Caterpillar plot from the lmer random effects --------------------
cat("\n==================================================================\n")
cat("(2) umg_caterpillar() on the lmer conditional modes (random effects)\n")
cat("==================================================================\n")
fit_sleep <- lmer(Reaction ~ Days + (Days | Subject), data = sleepstudy)
print(summary(fit_sleep), correlation = FALSE)
re <- ranef(fit_sleep, condVar = TRUE)$Subject
pv <- attr(ranef(fit_sleep, condVar = TRUE)$Subject, "postVar")   # 2 x 2 x 18
cat("\nranef()$Subject: ", nrow(re), " subjects x ", ncol(re), " effects (",
    paste(colnames(re), collapse = ", "), "); postVar dims: ",
    paste(dim(pv), collapse = " x "), "\n", sep = "")
cat("Does umg_caterpillar() accept the ranef object directly?\n")
r_direct <- report("umg_caterpillar(re)  [data frame without an 'estimate' column]",
                   umg_caterpillar(re))
cat("  ->", if (is.null(r_direct)) "refused (see error above)" else "accepted", "\n")
cat("Accepted input forms: a numeric vector (+ se), or a data frame with 'estimate' [, 'se', 'group'].\n")
df_int <- data.frame(group = rownames(re), estimate = re[, "(Intercept)"],
                     se = sqrt(pv[1, 1, ]))
df_slp <- data.frame(group = rownames(re), estimate = re[, "Days"],
                     se = sqrt(pv[2, 2, ]))
p_cat_int <- report("umg_caterpillar(df_int) [random intercepts]",
                    umg_caterpillar(df_int, title = "Caterpillar: random intercepts (Subject)"))
p_cat_slp <- report("umg_caterpillar(df_slp) [random slopes]",
                    umg_caterpillar(df_slp, title = "Caterpillar: random slopes for Days (Subject)"))
p_cat_vec <- report("umg_caterpillar(numeric vector, se = ...)",
                    umg_caterpillar(re[, "Days"], se = sqrt(pv[2, 2, ])))
if (!is.null(p_cat_int)) save_both(p_cat_int, "eda_caterpillar_intercepts_sleepstudy")
if (!is.null(p_cat_slp)) save_both(p_cat_slp, "eda_caterpillar_slopes_sleepstudy")

#----- (3) HS CFA diagram with the Holzinger-Swineford data ------------------
cat("\n==================================================================\n")
cat("(3) HS CFA diagram + HolzingerSwineford1939: umg_eda_scaffold()\n")
cat("==================================================================\n")
HS.model <- 'visual =~ x1+x2+x3; textual =~ x4+x5+x6; speed =~ x7+x8+x9'
fit_hs <- cfa(HS.model, data = HolzingerSwineford1939)
m_hs <- umg_from_lavaan(fit_hs)
sc_hs <- report("umg_eda_scaffold(m_hs, data = HolzingerSwineford1939)",
                umg_eda_scaffold(m_hs, data = HolzingerSwineford1939))
cat("\nNames:", paste(names(sc_hs), collapse = ", "), "\n")
for (nm in names(sc_hs)) {
  cat(sprintf("  $%s: class = %s; layers = %s\n", nm,
              paste(class(sc_hs[[nm]]), collapse = "/"),
              paste(vapply(sc_hs[[nm]]$layers, function(l) class(l$geom)[1], character(1)),
                    collapse = ", ")))
}
for (nm in names(sc_hs)) save_both(sc_hs[[nm]], paste0("eda_", nm, "_HS"))
cat("\nNo scatter_* display: the CFA has no dep edge between two observed vertices.\n",
    "The heat map falls back to all nine observed indicators because the cov\n",
    "edges join latent factors only (visual, textual, speed are not in the data).\n", sep = "")

cat("\n(3b) A MIMIC-style diagram on the same data produces scatter displays for\n",
    "observed -> latent is not drawn (latent target), but observed -> observed is:\n", sep = "")
m_reg <- umg_model(
  nodes = list(umg_node("ageyr", "$age_i$", observed = TRUE, dist = "free"),
               umg_node("x1", "$x_{1i}$", observed = TRUE),
               umg_node("x4", "$x_{4i}$", observed = TRUE)),
  edges = list(umg_edge("ageyr", "x1", "dep"), umg_edge("ageyr", "x4", "dep"),
               umg_edge("x1", "x4", "cov")),
  plates = list(umg_plate("person", c("ageyr", "x1", "x4"), "i = 1, ..., N")))
sc_reg <- report("umg_eda_scaffold(m_reg, HolzingerSwineford1939)",
                 umg_eda_scaffold(m_reg, data = HolzingerSwineford1939))
cat("Names:", paste(names(sc_reg), collapse = ", "), "\n")
for (nm in names(sc_reg)) save_both(sc_reg[[nm]], paste0("eda_", nm, "_HSreg"))

#----- (4) A mixture diagram: mixture-density display ------------------------
cat("\n==================================================================\n")
cat("(4) Growth mixture diagram on simulated two-class data: mixture density\n")
cat("==================================================================\n")
N <- 300
cls <- sample(1:2, N, replace = TRUE, prob = c(.6, .4))
I <- rnorm(N, c(30, 45)[cls], 4); S <- rnorm(N, c(1, 3.5)[cls], 1)
gm_dat <- as.data.frame(sapply(0:3, function(t) I + S * t + rnorm(N, 0, 3)))
names(gm_dat) <- paste0("y", 1:4)
m_gmm <- umg_mixture(umg_growth(4), c("I", "S"))
sc_gmm <- report("umg_eda_scaffold(umg_mixture(umg_growth(4), c('I','S')), gm_dat)",
                 umg_eda_scaffold(m_gmm, data = gm_dat))
cat("Names:", paste(names(sc_gmm), collapse = ", "), "\n")
for (nm in names(sc_gmm)) save_both(sc_gmm[[nm]], paste0("eda_", nm, "_gmm"))

cat("\nFiles written to", out_dir, ":\n")
print(sort(list.files(out_dir, pattern = "^eda_.*\\.(pdf|png)$")))
cat("\nDone:", format(Sys.time()), "\n")
sink()
close(con)

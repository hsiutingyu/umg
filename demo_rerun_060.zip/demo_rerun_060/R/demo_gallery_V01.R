# ============================================================
# Title:  Gallery of every umg motif builder, with validation and identification
# File:   demo_gallery_V01.R
# Author: HTYu
# Date:   2026-08-22
# ============================================================
# Renders every exported motif builder (umg_factor, umg_bifactor,
# umg_secondorder, umg_esem, umg_formative, umg_mimic, umg_sem, umg_irt
# for each item type and n_dim = 2, umg_dcm, umg_lca, umg_growth,
# umg_mixture, umg_riclpm, umg_network, umg_mediation) to PNG in
# output/gallery/, runs umg_validate() and umg_identify() on each, and
# tabulates vertex/edge counts (as.data.frame / summary).
# Run: Rscript R/demo_gallery_V01.R
# Output: output/demo_gallery_V01.txt, output/gallery/*.png,
#         output/gallery_table_V01.csv

#----- Packages & Setup -----------------------------------------------------
library(umg)

script_dir <- local({
  a <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", a[grepl("^--file=", a)])
  if (length(f)) dirname(normalizePath(f[1])) else getwd()
})
out_dir <- normalizePath(file.path(script_dir, "..", "output"),
                         mustWork = FALSE)
gal_dir <- file.path(out_dir, "gallery")
dir.create(gal_dir, showWarnings = FALSE, recursive = TRUE)

con <- file(file.path(out_dir, "demo_gallery_V01.txt"), open = "wt")
sink(con, split = TRUE)
cat("demo_gallery_V01.R  --  run on", format(Sys.time()), "\n")
cat("R ", R.version$major, ".", R.version$minor,
    "; umg ", as.character(packageVersion("umg")), "\n\n", sep = "")
cat("Exported functions of umg:\n"); print(ls("package:umg"))

# Condition-capturing evaluator: returns list(value, warnings, messages, error)
capture <- function(expr) {
  w <- character(0); m <- character(0); err <- NULL
  val <- withCallingHandlers(
    tryCatch(expr, error = function(e) { err <<- conditionMessage(e); NULL }),
    warning = function(x) { w <<- c(w, conditionMessage(x)); invokeRestart("muffleWarning") },
    message = function(x) { m <<- c(m, conditionMessage(x)); invokeRestart("muffleMessage") })
  list(value = val, warnings = w, messages = m, error = err)
}

#----- Motif specifications ------------------------------------------------
Q_small <- rbind(c(1, 1, 0, 0), c(0, 1, 1, 1))   # 2 attributes x 4 items (K x J)
motifs <- list(
  factor        = quote(umg_factor("F", paste0("y", 1:4))),
  bifactor      = quote(umg_bifactor(paste0("y", 1:6),
                                     groups = list(f1 = paste0("y", 1:3), f2 = paste0("y", 4:6)))),
  secondorder   = quote(umg_secondorder(list(F1 = paste0("y", 1:3), F2 = paste0("y", 4:6),
                                             F3 = paste0("y", 7:9)))),
  esem          = quote(umg_esem(c("F1", "F2"), paste0("y", 1:6))),
  formative     = quote(umg_formative(paste0("x", 1:4), outcomes = c("y1", "y2"))),
  mimic         = quote(umg_mimic(c("z1", "z2"), paste0("y", 1:4))),
  sem_marker    = quote(umg_sem(measurement = list(F1 = paste0("y", 1:3), F2 = paste0("y", 4:6)),
                                structural = list(c("F1", "F2")))),
  sem_variance  = quote(umg_sem(measurement = list(F1 = paste0("y", 1:3), F2 = paste0("y", 4:6)),
                                structural = list(c("F1", "F2")), scaling = "variance")),
  irt_1PL       = quote(umg_irt("1PL")),
  irt_2PL       = quote(umg_irt("2PL")),
  irt_3PL       = quote(umg_irt("3PL")),
  irt_graded    = quote(umg_irt("graded")),
  irt_PCM       = quote(umg_irt("PCM")),
  irt_GPCM      = quote(umg_irt("GPCM")),
  irt_2PL_2dim  = quote(umg_irt("2PL", n_dim = 2)),
  dcm           = quote(umg_dcm(Q_small)),
  dcm_nocov     = quote(umg_dcm(Q_small, attr_cov = FALSE)),
  lca           = quote(umg_lca(paste0("u", 1:4))),
  lpa           = quote(umg_lca(paste0("y", 1:4), categorical = FALSE)),
  growth        = quote(umg_growth(4)),
  mixture_gmm   = quote(umg_mixture(umg_growth(4), c("I", "S"))),
  riclpm        = quote(umg_riclpm(waves = 4)),
  network       = quote(umg_network(paste0("x", 1:5))),
  mediation     = quote(umg_mediation()),
  mediation_U   = quote(umg_mediation(confounder = TRUE, badge = "structural"))
)

#----- Build, validate, identify, render -------------------------------------
rows <- list()
for (nm in names(motifs)) {
  cat("\n==================================================================\n")
  cat(nm, ":", deparse(motifs[[nm]]), "\n")
  cat("==================================================================\n")
  b <- capture(eval(motifs[[nm]]))
  if (length(b$warnings)) cat("  build WARNING:", paste(b$warnings, collapse = " | "), "\n")
  if (!is.null(b$error)) { cat("  build ERROR:", b$error, "\n"); next }
  m <- b$value
  print(m)

  v <- capture(umg_validate(m))
  cat("  umg_validate():", if (isTRUE(v$value)) "TRUE (well-formed)" else paste("ERROR:", v$error),
      if (length(v$warnings)) paste("| warnings:", paste(v$warnings, collapse = " | ")) else "", "\n")

  id <- capture(umg_identify(m))
  if (length(id$warnings)) cat("  umg_identify() WARNING:", paste(id$warnings, collapse = " | "), "\n")
  if (!is.null(id$error)) cat("  umg_identify() ERROR:", id$error, "\n") else print(id$value)

  s <- capture(summary(m))
  if (!is.null(s$value)) print(s$value)

  vdf <- as.data.frame(m, what = "vertices"); edf <- as.data.frame(m)
  png_file <- file.path(gal_dir, paste0("gallery_", nm, ".png"))
  r <- capture({ png(png_file, width = 1600, height = 1200, res = 200); plot(m); dev.off() })
  if (length(r$warnings)) cat("  plot() WARNING:", paste(r$warnings, collapse = " | "), "\n")
  if (!is.null(r$error)) cat("  plot() ERROR:", r$error, "\n")
  cat("  rendered:", basename(png_file), if (file.exists(png_file)) "" else "(MISSING)", "\n")
  # also the ggplot backend, as a second rendering check
  g <- capture(umg_ggplot(m))
  if (!is.null(g$value)) {
    gg_file <- file.path(gal_dir, paste0("gallery_", nm, "_ggplot.png"))
    r2 <- capture(ggplot2::ggsave(gg_file, g$value, width = 8, height = 6, dpi = 150))
    if (!is.null(r2$error)) cat("  ggplot save ERROR:", r2$error, "\n")
  } else cat("  umg_ggplot() ERROR:", g$error, "\n")

  cnt <- id$value$count
  sc <- id$value$scaling
  rows[[nm]] <- data.frame(
    motif = nm, call = paste(deparse(motifs[[nm]]), collapse = ""),
    badge = m$badge,
    n_vertices = nrow(vdf),
    n_observed_rv = sum(vdf$observed & vdf$role == "rv"),
    n_latent_rv = sum(!vdf$observed & vdf$role == "rv"),
    n_latent_categorical = sum(!vdf$observed & vdf$role == "rv" & vdf$support == "categorical"),
    n_par = sum(vdf$role == "par"), n_const = sum(vdf$role == "const"),
    n_edges = nrow(edf),
    n_dep = sum(edf$kind == "dep"), n_cov = sum(edf$kind == "cov"),
    n_det = sum(edf$kind == "det"), n_mix = sum(edf$kind == "mix"),
    n_fixed_edges = sum(!is.na(edf$fixed)),
    n_plates = length(m$plates),
    plates = paste(vapply(m$plates, `[[`, character(1), "name"), collapse = "+"),
    valid = isTRUE(v$value),
    all_scaled = if (nrow(sc)) all(sc$scaled) else NA,
    unscaled = if (nrow(sc)) paste(sc$vertex[!sc$scaled], collapse = ",") else "",
    moments = cnt$data_information, free = cnt$free_total,
    df = if (is.na(cnt$df)) NA else cnt$df,
    count_applicable = cnt$applicable,
    label_switching = paste(id$value$label_switching, collapse = ","),
    n_implied_ci_obs = nrow(id$value$implied_ci),
    warnings = paste(unique(c(b$warnings, id$warnings, r$warnings)), collapse = " | "),
    stringsAsFactors = FALSE)
}

#----- Table -----------------------------------------------------------------
tab <- do.call(rbind, rows); rownames(tab) <- NULL
cat("\n==================================================================\n")
cat("Gallery table (vertex/edge counts, validation, identification)\n")
cat("==================================================================\n")
options(width = 200)
print(tab[, c("motif", "n_vertices", "n_observed_rv", "n_latent_rv", "n_latent_categorical",
              "n_par", "n_edges", "n_dep", "n_cov", "n_mix", "n_fixed_edges", "n_plates",
              "valid", "all_scaled", "moments", "free", "df", "count_applicable",
              "label_switching", "n_implied_ci_obs")], row.names = FALSE)
write.csv(tab, file.path(out_dir, "gallery_table_V01.csv"), row.names = FALSE)
cat("\nTable written to", file.path(out_dir, "gallery_table_V01.csv"), "\n")
cat("Warnings recorded per motif:\n")
for (i in seq_len(nrow(tab))) if (nzchar(tab$warnings[i])) cat("  ", tab$motif[i], ":", tab$warnings[i], "\n")

#----- Hand-checks of a few counts -------------------------------------------
cat("\nHand-checks:\n")
chk <- function(motif, expr, expected) {
  val <- tab[tab$motif == motif, expr]
  cat(sprintf("  %-14s %-10s = %-4s expected %-4s %s\n", motif, expr, val, expected,
              if (isTRUE(all.equal(val, expected))) "OK" else "MISMATCH"))
}
chk("factor", "df", 2)            # 10 moments - (3 loadings + 5 variances)
chk("growth", "free", 7)          # 2 var + 1 cov + 4 residual variances (loadings fixed)
chk("growth", "df", 3)            # 10 - 7
chk("riclpm", "free", 27); chk("riclpm", "df", 9)
chk("esem", "free", 19)           # 12 loadings + 1 cov + 6 residual var (factor var fixed to 1)
chk("esem", "df", 2)              # 21 - 19 (the m(m-1) = 2 rotational constraints of EFA are
                                  # not encoded in the diagram; EFA df would be 4)
chk("bifactor", "free", 18)       # 12 loadings + 6 residual var (g, f1, f2 var fixed to 1)
chk("bifactor", "df", 3)          # 21 - 18
chk("network", "free", 15)        # 10 cov + 5 var (saturated): df = 0
chk("network", "df", 0)
chk("mediation", "free", 6)       # 3 paths + 3 var; 6 moments -> df 0
chk("sem_marker", "free", 13)     # 4 free loadings + 1 regression + 8 variances
chk("sem_marker", "df", 8)        # 21 - 13
chk("secondorder", "free", 21)    # 2 + 6 free loadings + 13 variances
chk("secondorder", "df", 24)      # 45 - 21
chk("mimic", "free", 12)          # 2 gammas + 3 free loadings + 7 variances (z1, z2 exogenous)
chk("mimic", "df", 9)             # 21 - 12; NB no z1 <-> z2 cov edge is drawn, so the diagram
                                  # literally asserts cov(z1, z2) = 0 (lavaan's MIMIC would have df = 8)
chk("formative", "free", 13)      # 4 weights + 2 outcome loadings + 7 variances
cat("\nNote: umg_formative() yields all_scaled =", tab$all_scaled[tab$motif == "formative"],
    "(unscaled:", tab$unscaled[tab$motif == "formative"], ") -- the composite carries",
    "no marker weight and a symbolic disturbance variance, so the package's own",
    "scaling check flags the motif builder's output.\n")

cat("\nGallery PNGs:\n"); print(list.files(gal_dir))
cat("\nDone:", format(Sys.time()), "\n")
sink()
close(con)

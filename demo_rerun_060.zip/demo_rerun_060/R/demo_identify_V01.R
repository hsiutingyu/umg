# ============================================================
# Title:  Identification diagnostics read off UMG diagrams
# File:   demo_identify_V01.R
# Author: HTYu
# Date:   2026-08-22
# ============================================================
# (a) umg_identify() on a one-factor model and on the Holzinger-
#     Swineford three-factor CFA diagram (scaling check, counting rule,
#     label-switching flag, implied conditional independencies), with
#     the counting-rule df compared against lavaan's df;
# (b) umg_riclpm(waves = 4): expected 27 free parameters, df = 9;
# (c) umg_mixture(umg_growth(4), c("I", "S")): label switching flagged,
#     counting rule declared inapplicable;
# (d) a one-factor diagram with no scaling constraint flagged by
#     umg_check_scaling(), then the fixed versions passing.
# Run: Rscript R/demo_identify_V01.R
# Output: output/demo_identify_V01.txt

#----- Packages & Setup -----------------------------------------------------
library(lavaan)
library(umg)
set.seed(20260822)

script_dir <- local({
  a <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", a[grepl("^--file=", a)])
  if (length(f)) dirname(normalizePath(f[1])) else getwd()
})
out_dir <- normalizePath(file.path(script_dir, "..", "output"),
                         mustWork = FALSE)
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

con <- file(file.path(out_dir, "demo_identify_V01.txt"), open = "wt")
sink(con, split = TRUE)
cat("demo_identify_V01.R  --  run on", format(Sys.time()), "\n")
cat("R ", R.version$major, ".", R.version$minor,
    "; lavaan ", as.character(packageVersion("lavaan")),
    "; umg ", as.character(packageVersion("umg")), "\n\n", sep = "")

# Helper: evaluate and transcribe warnings/messages/errors verbatim.
report <- function(label, expr) {
  cat("\n>>> ", label, "\n", sep = "")
  withCallingHandlers(
    tryCatch(expr, error = function(e) {
      cat("    ERROR: ", conditionMessage(e), "\n", sep = ""); NULL }),
    warning = function(w) {
      cat("    WARNING: ", conditionMessage(w), "\n", sep = "")
      invokeRestart("muffleWarning") },
    message = function(m) {
      cat("    MESSAGE: ", conditionMessage(m), sep = "")
      invokeRestart("muffleMessage") })
}

# Helper: full identification report for one diagram.
full_report <- function(m, name) {
  cat("\n------------------------------------------------------------\n")
  cat("Diagram:", name, "\n")
  cat("------------------------------------------------------------\n")
  print(m)
  id <- report("umg_identify(m)", umg_identify(m))
  if (!is.null(id)) print(id)
  cat("\n  Scaling check (umg_check_scaling):\n")
  print(report("umg_check_scaling(m)", umg_check_scaling(m)))
  cnt <- report("umg_count_parameters(m)", umg_count_parameters(m))
  if (!is.null(cnt)) {
    cat("  Counting rule: data moments =", cnt$data_information,
        "| free: loadings/regressions =", cnt$free$loadings_regressions,
        ", covariances =", cnt$free$covariances,
        ", variances =", cnt$free$variances,
        ", means =", cnt$free$means,
        "| total free =", cnt$free_total,
        "| df =", cnt$df, "| applicable =", cnt$applicable, "\n")
  }
  ls <- report("umg_labelswitching(m)", umg_labelswitching(m))
  cat("  Label-switching vertices:",
      if (length(ls)) paste(ls, collapse = ", ") else "(none)", "\n")
  ci1 <- report("umg_implied_ci(m, observed_only = TRUE)",
                umg_implied_ci(m, observed_only = TRUE))
  cat("  Implied CIs (observed_only = TRUE): n =", nrow(ci1), "\n")
  if (nrow(ci1)) print(ci1, row.names = FALSE)
  ci2 <- report("umg_implied_ci(m, observed_only = FALSE)",
                umg_implied_ci(m, observed_only = FALSE))
  cat("  Implied CIs (observed_only = FALSE): n =", nrow(ci2), "\n")
  if (nrow(ci2)) print(head(ci2, 12), row.names = FALSE)
  if (nrow(ci2) > 12) cat("  ... (", nrow(ci2) - 12, " more rows)\n", sep = "")
  invisible(list(id = id, cnt = cnt, ls = ls, ci1 = ci1, ci2 = ci2))
}

#----- (a) One-factor model and the HS three-factor CFA ---------------------
cat("==================================================================\n")
cat("(a) umg_identify() on umg_factor('F', y1..y4) and on the HS CFA diagram\n")
cat("==================================================================\n")
m_f4 <- umg_factor("F", paste0("y", 1:4))
r_f4 <- full_report(m_f4, "umg_factor('F', y1..y4)")
cat("\nExpected by hand: 4*5/2 = 10 moments; free = 3 loadings + 5 variances",
    "(F, y1..y4) = 8; df = 2.\n")

HS.model <- 'visual =~ x1+x2+x3; textual =~ x4+x5+x6; speed =~ x7+x8+x9'
fit_hs <- cfa(HS.model, data = HolzingerSwineford1939)
m_hs <- umg_from_lavaan(fit_hs)
r_hs <- full_report(m_hs, "HS three-factor CFA via umg_from_lavaan(fit)")
cat(sprintf("\nCounting-rule df from the diagram = %s; lavaan df = %d; npar: diagram %s vs lavaan %d\n",
            r_hs$cnt$df, fitMeasures(fit_hs, "df"),
            r_hs$cnt$free_total, fitMeasures(fit_hs, "npar")))
cat("Agreement on df:", isTRUE(r_hs$cnt$df == fitMeasures(fit_hs, "df")), "\n")

cat("\nFor reference, the same CFA built from a motif (umg_sem with three factors\n",
    "and free factor covariances):\n", sep = "")
m_hs_motif <- umg_sem(measurement = list(visual = paste0("x", 1:3),
                                         textual = paste0("x", 4:6),
                                         speed = paste0("x", 7:9)),
                      covariances = list(c("visual", "textual"),
                                         c("visual", "speed"),
                                         c("textual", "speed")))
cnt_motif <- umg_count_parameters(m_hs_motif)
cat(sprintf("  umg_sem motif: %d moments, %d free, df = %d\n",
            cnt_motif$data_information, cnt_motif$free_total, cnt_motif$df))

#----- (b) RI-CLPM with four waves -------------------------------------------
cat("\n==================================================================\n")
cat("(b) umg_riclpm(waves = 4): NEWS states 27 free parameters and df = 9\n")
cat("==================================================================\n")
m_ri <- umg_riclpm(waves = 4)
r_ri <- full_report(m_ri, "umg_riclpm(waves = 4)")
cat(sprintf("\nResult: free_total = %d (expected 27), df = %d (expected 9): %s\n",
            r_ri$cnt$free_total, r_ri$cnt$df,
            if (r_ri$cnt$free_total == 27 && r_ri$cnt$df == 9) "MATCHES NEWS" else "DOES NOT MATCH"))
cat("Breakdown: 8 observed -> 36 moments; lagged paths =", r_ri$cnt$free$loadings_regressions,
    "; covariances =", r_ri$cnt$free$covariances,
    "; variances =", r_ri$cnt$free$variances, "\n")
cat("Cross-check against lavaan: lavaanify() the textbook RI-CLPM (4 waves) and\n",
    "count free parameters / df with a saturated covariance structure:\n", sep = "")
riclpm_syntax <- '
  RIx =~ 1*x1 + 1*x2 + 1*x3 + 1*x4
  RIy =~ 1*y1 + 1*y2 + 1*y3 + 1*y4
  wx1 =~ 1*x1; wx2 =~ 1*x2; wx3 =~ 1*x3; wx4 =~ 1*x4
  wy1 =~ 1*y1; wy2 =~ 1*y2; wy3 =~ 1*y3; wy4 =~ 1*y4
  wx2 ~ wx1 + wy1; wy2 ~ wx1 + wy1
  wx3 ~ wx2 + wy2; wy3 ~ wx2 + wy2
  wx4 ~ wx3 + wy3; wy4 ~ wx3 + wy3
  RIx ~~ RIy
  wx1 ~~ wy1; wx2 ~~ wy2; wx3 ~~ wy3; wx4 ~~ wy4
  x1 ~~ 0*x1; x2 ~~ 0*x2; x3 ~~ 0*x3; x4 ~~ 0*x4
  y1 ~~ 0*y1; y2 ~~ 0*y2; y3 ~~ 0*y3; y4 ~~ 0*y4
  RIx ~~ 0*wx1; RIx ~~ 0*wy1; RIy ~~ 0*wx1; RIy ~~ 0*wy1
'
pt_ri <- lavaanify(riclpm_syntax, auto = TRUE, model.type = "sem",
                   auto.cov.lv.x = FALSE)
n_free_ri <- max(pt_ri$free)
cat(sprintf("  lavaanify(): %d free parameters; 36 moments -> df = %d\n",
            n_free_ri, 36 - n_free_ri))
cat("  (auto.cov.lv.x = FALSE so that no extra exogenous-latent covariances are added)\n")

#----- (c) Growth mixture model ----------------------------------------------
cat("\n==================================================================\n")
cat("(c) umg_mixture(umg_growth(4), c('I', 'S')): label switching and counting rule\n")
cat("==================================================================\n")
m_gmm <- umg_mixture(umg_growth(4), c("I", "S"))
r_gmm <- full_report(m_gmm, "umg_mixture(umg_growth(4), c('I','S'))")
cat(sprintf("\nLabel switching flagged for: %s\n", paste(r_gmm$ls, collapse = ", ")))
cat(sprintf("Counting rule applicable = %s; df = %s\n",
            r_gmm$cnt$applicable, r_gmm$cnt$df))
cat("Summary method on the same diagram (note how df prints):\n")
report("summary(m_gmm)", print(summary(m_gmm)))

#----- (d) Scaling: unscaled one-factor diagram vs fixed versions -------------
cat("\n==================================================================\n")
cat("(d) One-factor diagram WITHOUT any scaling constraint, then fixed versions\n")
cat("==================================================================\n")
nodes_u <- list(
  umg_node("F", "$F_i$", observed = FALSE, dist = "N(0, psi)"),  # psi symbolic: variance free
  umg_node("y1", "$y_{1i}$", observed = TRUE),
  umg_node("y2", "$y_{2i}$", observed = TRUE),
  umg_node("y3", "$y_{3i}$", observed = TRUE)
)
edges_u <- list(
  umg_edge("F", "y1", "dep", label = "$\\lambda_1$"),   # no fixed marker
  umg_edge("F", "y2", "dep", label = "$\\lambda_2$"),
  umg_edge("F", "y3", "dep", label = "$\\lambda_3$")
)
plate_u <- list(umg_plate("person", c("F", "y1", "y2", "y3"), "i = 1, ..., N"))
m_unscaled <- umg_model(nodes_u, edges_u, plate_u)
cat("\nUnscaled diagram: all three loadings free, factor variance symbolic (psi)\n")
sc_u <- report("umg_check_scaling(m_unscaled)", umg_check_scaling(m_unscaled))
print(sc_u)
cat("Flagged as unscaled:", any(!sc_u$scaled), "\n")
cat("umg_identify() print (note the UNSCALED line and the counting rule):\n")
print(report("umg_identify(m_unscaled)", umg_identify(m_unscaled)))
cat("Note: the counting rule alone would not catch this (6 moments, 7 free,\n",
    "df = -1 here, but with 4 indicators it would be 10 vs 9: df = 1 and the\n",
    "model is still unidentified without a scaling constraint). The scaling\n",
    "check is the one that catches it:\n", sep = "")
m_unscaled4 <- umg_model(c(nodes_u, list(umg_node("y4", "$y_{4i}$", observed = TRUE))),
                         c(edges_u, list(umg_edge("F", "y4", "dep", label = "$\\lambda_4$"))),
                         list(umg_plate("person", c("F", paste0("y", 1:4)), "i = 1, ..., N")))
print(report("umg_identify(m_unscaled4)", umg_identify(m_unscaled4)))

cat("\nFixed version 1: marker loading (F -> y1 fixed to 1)\n")
edges_marker <- edges_u
edges_marker[[1]] <- umg_edge("F", "y1", "dep", fixed = 1)
m_marker <- umg_model(nodes_u, edges_marker, plate_u)
print(report("umg_check_scaling(m_marker)", umg_check_scaling(m_marker)))
print(report("umg_identify(m_marker)", umg_identify(m_marker)))

cat("\nFixed version 2: fixed factor variance (dist = 'N(0, 1)'), all loadings free\n")
nodes_var <- nodes_u
nodes_var[[1]] <- umg_node("F", "$F_i$", observed = FALSE, dist = "N(0, 1)")
m_var <- umg_model(nodes_var, edges_u, plate_u)
print(report("umg_check_scaling(m_var)", umg_check_scaling(m_var)))
print(report("umg_identify(m_var)", umg_identify(m_var)))

cat("\nFixed version 3: constant parent (a 'const' vertex pointing at F)\n")
nodes_const <- c(nodes_u, list(umg_node("one", "$1$", role = "const")))
edges_const <- c(edges_u, list(umg_edge("one", "F", "dep")))
m_const <- umg_model(nodes_const, edges_const, plate_u)
print(report("umg_check_scaling(m_const)", umg_check_scaling(m_const)))

cat("\nEdge case: 'var = free' annotation (as written by umg_from_lavaan) is NOT a fixed variance:\n")
nodes_vf <- nodes_u
nodes_vf[[1]] <- umg_node("F", "$F_i$", observed = FALSE, dist = "var = free")
print(report("umg_check_scaling(var = free)", umg_check_scaling(umg_model(nodes_vf, edges_u, plate_u))))
cat("Edge case: lavaan std.lv = TRUE fit converted with umg_from_lavaan():\n")
fit_std <- cfa('F =~ y1 + y2 + y3', data = setNames(as.data.frame(matrix(rnorm(300), 100, 3)),
                                                   c("y1", "y2", "y3")), std.lv = TRUE)
m_std <- umg_from_lavaan(fit_std)
print(as.data.frame(m_std, what = "vertices")[, c("name", "observed", "dist")])
print(as.data.frame(m_std))
print(report("umg_check_scaling(umg_from_lavaan(std.lv fit))", umg_check_scaling(m_std)))
print(report("umg_count_parameters(std.lv fit)", umg_count_parameters(m_std)))
cat(sprintf("lavaan (std.lv = TRUE): npar = %d, df = %d\n",
            fitMeasures(fit_std, "npar"), fitMeasures(fit_std, "df")))

cat("\nDone:", format(Sys.time()), "\n")
sink()
close(con)

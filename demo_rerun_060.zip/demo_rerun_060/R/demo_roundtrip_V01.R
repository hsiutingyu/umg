# ============================================================
# Title:  lavaan -> UMG -> lavaan round trip (HS CFA and a growth model)
# File:   demo_roundtrip_V01.R
# Author: HTYu
# Date:   2026-08-22
# ============================================================
# Fits the Holzinger-Swineford three-factor CFA and a linear latent
# growth model in lavaan, converts each fit to a UMG with
# umg_from_lavaan(), emits lavaan syntax back from the diagram with
# umg_to_lavaan(), refits the emitted syntax, and compares the two
# fits (free parameters, df, chi-square, CFI, RMSEA, SRMR, and the
# maximum absolute difference in parameter estimates matched by
# lhs/op/rhs).
# Run: Rscript R/demo_roundtrip_V01.R
# Output: output/demo_roundtrip_V01.txt,
#         output/roundtrip_hs_emitted_V01.lav,
#         output/roundtrip_growth_emitted_V01.lav

#----- Packages & Setup -----------------------------------------------------
library(lavaan)
library(umg)

script_dir <- local({
  a <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", a[grepl("^--file=", a)])
  if (length(f)) dirname(normalizePath(f[1])) else getwd()
})
out_dir <- normalizePath(file.path(script_dir, "..", "output"),
                         mustWork = FALSE)
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

con <- file(file.path(out_dir, "demo_roundtrip_V01.txt"), open = "wt")
sink(con, split = TRUE)
cat("demo_roundtrip_V01.R  --  run on", format(Sys.time()), "\n")
cat("R ", R.version$major, ".", R.version$minor,
    "; lavaan ", as.character(packageVersion("lavaan")),
    "; umg ", as.character(packageVersion("umg")), "\n\n", sep = "")

# Helper: compare two lavaan fits.
compare_fits <- function(fit1, fit2, label) {
  cat("\n----- Comparison:", label, "-----\n")
  fm <- c("npar", "df", "chisq", "cfi", "rmsea", "srmr")
  f1 <- fitMeasures(fit1, fm); f2 <- fitMeasures(fit2, fm)
  tab <- data.frame(measure = fm, original = as.numeric(f1),
                    refit = as.numeric(f2),
                    abs_diff = abs(as.numeric(f1) - as.numeric(f2)))
  print(tab, digits = 6, row.names = FALSE)
  cat(sprintf("Free parameters (original / refit): %d / %d\n",
              fitMeasures(fit1, "npar"), fitMeasures(fit2, "npar")))
  cat(sprintf("df (original / refit): %d / %d\n",
              fitMeasures(fit1, "df"), fitMeasures(fit2, "df")))
  pe1 <- parameterEstimates(fit1); pe2 <- parameterEstimates(fit2)
  key1 <- paste(pe1$lhs, pe1$op, pe1$rhs)
  key2 <- paste(pe2$lhs, pe2$op, pe2$rhs)
  common <- intersect(key1, key2)
  cat(sprintf("Parameter rows (original / refit / matched by lhs-op-rhs): %d / %d / %d\n",
              nrow(pe1), nrow(pe2), length(common)))
  if (length(setdiff(key1, key2)))
    cat("  rows only in original:", paste(setdiff(key1, key2), collapse = "; "), "\n")
  if (length(setdiff(key2, key1)))
    cat("  rows only in refit:", paste(setdiff(key2, key1), collapse = "; "), "\n")
  d <- abs(pe1$est[match(common, key1)] - pe2$est[match(common, key2)])
  cat(sprintf("Max |difference| in estimates over matched rows: %.3e (row: %s)\n",
              max(d), common[which.max(d)]))
  dse <- abs(pe1$se[match(common, key1)] - pe2$se[match(common, key2)])
  cat(sprintf("Max |difference| in standard errors: %.3e\n", max(dse)))
  invisible(tab)
}

#----- Round trip 1: Holzinger-Swineford three-factor CFA --------------------
cat("==================================================================\n")
cat("Round trip 1: Holzinger-Swineford three-factor CFA\n")
cat("==================================================================\n")
HS.model <- 'visual =~ x1+x2+x3; textual =~ x4+x5+x6; speed =~ x7+x8+x9'
fit_hs <- cfa(HS.model, data = HolzingerSwineford1939)
cat("\nOriginal fit:\n")
print(fitMeasures(fit_hs, c("npar", "df", "chisq", "pvalue", "cfi", "rmsea", "srmr")))

m_hs <- umg_from_lavaan(fit_hs)
cat("\nUMG built from the fitted object:\n")
print(m_hs)
print(summary(m_hs))
cat("\nEdges of the diagram:\n")
print(as.data.frame(m_hs))
cat("\nVertices of the diagram (variance annotations carried in 'dist'):\n")
print(as.data.frame(m_hs, what = "vertices")[, c("name", "observed", "support", "role", "dist")])

syn_hs <- umg_to_lavaan(m_hs)
cat("\nEmitted lavaan syntax (umg_to_lavaan):\n")
cat(syn_hs, "\n")
writeLines(syn_hs, file.path(out_dir, "roundtrip_hs_emitted_V01.lav"))

fit_hs2 <- cfa(syn_hs, data = HolzingerSwineford1939)
cat("\nRefit of the emitted syntax with cfa():\n")
print(fitMeasures(fit_hs2, c("npar", "df", "chisq", "pvalue", "cfi", "rmsea", "srmr")))
compare_fits(fit_hs, fit_hs2, "HS CFA: original vs refit of emitted syntax")

cat("\nCounting rule read from the diagram vs lavaan df:\n")
cnt_hs <- umg_count_parameters(m_hs)
cat(sprintf("  diagram: %d moments, %d free parameters, df = %d; lavaan: npar = %d, df = %d\n",
            cnt_hs$data_information, cnt_hs$free_total, cnt_hs$df,
            fitMeasures(fit_hs, "npar"), fitMeasures(fit_hs, "df")))

#----- Round trip 2: linear latent growth model (Demo.growth) ----------------
cat("\n==================================================================\n")
cat("Round trip 2: linear latent growth model on lavaan's Demo.growth\n")
cat("==================================================================\n")
growth.model <- 'i =~ 1*t1+1*t2+1*t3+1*t4; s =~ 0*t1+1*t2+2*t3+3*t4'
fit_gr <- growth(growth.model, data = Demo.growth)
cat("\nOriginal fit (growth(): mean structure with latent means free):\n")
print(fitMeasures(fit_gr, c("npar", "df", "chisq", "pvalue", "cfi", "rmsea", "srmr")))

m_gr <- umg_from_lavaan(fit_gr)
cat("\nUMG built from the fitted object:\n")
print(m_gr)
print(summary(m_gr))
cat("\nEdges of the diagram:\n")
print(as.data.frame(m_gr))
cat("\nVertices of the diagram:\n")
print(as.data.frame(m_gr, what = "vertices")[, c("name", "observed", "support", "role", "dist")])

syn_gr <- umg_to_lavaan(m_gr)
cat("\nEmitted lavaan syntax (umg_to_lavaan):\n")
cat(syn_gr, "\n")
writeLines(syn_gr, file.path(out_dir, "roundtrip_growth_emitted_V01.lav"))

cat("\n(2a) Refit of the emitted syntax with growth(), the same fitting function:\n")
fit_gr2 <- growth(syn_gr, data = Demo.growth)
print(fitMeasures(fit_gr2, c("npar", "df", "chisq", "pvalue", "cfi", "rmsea", "srmr")))
compare_fits(fit_gr, fit_gr2, "growth: original vs growth() refit of emitted syntax")

cat("\n(2b) Refit of the emitted syntax with cfa() (no mean structure), as a check\n",
    "that the diagram carries the covariance structure only: the '~1' rows of\n",
    "the parameter table are not represented in the UMG, so the mean\n",
    "structure is supplied by the fitting function, not by the diagram.\n", sep = "")
fit_gr3 <- cfa(syn_gr, data = Demo.growth)
print(fitMeasures(fit_gr3, c("npar", "df", "chisq", "pvalue", "cfi", "rmsea", "srmr")))
compare_fits(fit_gr, fit_gr3, "growth: original (growth) vs cfa() refit of emitted syntax")

cat("\nCounting rule read from the diagram (meanstructure = FALSE / TRUE) vs lavaan:\n")
cnt_gr <- umg_count_parameters(m_gr)
cnt_gr_m <- umg_count_parameters(m_gr, meanstructure = TRUE)
cat(sprintf("  diagram, no means: %d moments, %d free, df = %d\n",
            cnt_gr$data_information, cnt_gr$free_total, cnt_gr$df))
cat(sprintf("  diagram, meanstructure = TRUE: %d moments, %d free, df = %d\n",
            cnt_gr_m$data_information, cnt_gr_m$free_total, cnt_gr_m$df))
cat(sprintf("  lavaan growth(): npar = %d, df = %d\n",
            fitMeasures(fit_gr, "npar"), fitMeasures(fit_gr, "df")))
cat("  (lavaan's growth() frees the 2 latent means and fixes the 4 observed\n",
    "   intercepts at 0: 4 means of data, 2 free mean parameters -> +2 df;\n",
    "   umg's meanstructure = TRUE counts one free mean per random vertex.)\n")

#----- Session ---------------------------------------------------------------
cat("\nFiles written:\n")
cat("  ", file.path(out_dir, "roundtrip_hs_emitted_V01.lav"), "\n")
cat("  ", file.path(out_dir, "roundtrip_growth_emitted_V01.lav"), "\n")
cat("\nDone:", format(Sys.time()), "\n")
sink()
close(con)

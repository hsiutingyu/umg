# ============================================================
# Title:  Well-formedness validation of UMG diagrams (rules W1-W6)
# File:   demo_validate_V01.R
# Author: HTYu
# Date:   2026-08-22
# ============================================================
# Builds (a) a valid two-indicator factor diagram, then four
# deliberately ill-formed diagrams: (b) a directed cycle, (c) a mixing
# edge whose source is a continuous latent vertex, (d) a covariance
# edge joining a parameter vertex, and (e) an edge that crosses a plate
# boundary in a way the index structure does not license. For each,
# umg_model() (which validates on construction) and umg_validate()
# are called and the exact outcome (accepted / refused, message text)
# is recorded.
# Run: Rscript R/demo_validate_V01.R      (from the osf/ folder or anywhere)
# Output: output/demo_validate_V01.txt

#----- Packages & Setup -----------------------------------------------------
library(umg)

script_dir <- local({
  a <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", a[grepl("^--file=", a)])
  if (length(f)) dirname(normalizePath(f[1])) else getwd()
})
out_dir <- normalizePath(file.path(script_dir, "..", "output"),
                         mustWork = FALSE)
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

con <- file(file.path(out_dir, "demo_validate_V01.txt"), open = "wt")
sink(con, split = TRUE)
cat("demo_validate_V01.R  --  run on", format(Sys.time()), "\n")
cat("R", R.version$major, ".", R.version$minor, "; umg ",
    as.character(packageVersion("umg")), "\n\n", sep = "")

# Helper: run an expression, print its value, and record any error,
# warning, or message text verbatim (conditions are turned into text
# so that the .txt file is a faithful transcript).
report <- function(label, expr) {
  cat("\n>>> ", label, "\n", sep = "")
  res <- withCallingHandlers(
    tryCatch(expr,
             error = function(e) {
               cat("    REFUSED (error): ", conditionMessage(e), "\n", sep = "")
               structure(list(message = conditionMessage(e)),
                         class = "demo_error")
             }),
    warning = function(w) {
      cat("    WARNING: ", conditionMessage(w), "\n", sep = "")
      invokeRestart("muffleWarning")
    },
    message = function(m) {
      cat("    MESSAGE: ", conditionMessage(m), sep = "")
      invokeRestart("muffleMessage")
    })
  if (inherits(res, "umg")) {
    cat("    ACCEPTED: object of class 'umg' returned\n")
    print(res)
  } else if (isTRUE(res)) {
    cat("    ACCEPTED: umg_validate() returned TRUE\n")
  }
  invisible(res)
}

#----- (a) Valid two-indicator factor diagram (README example) -------------
cat("\n==================================================================\n")
cat("(a) Valid two-indicator factor diagram (as in the package README)\n")
cat("==================================================================\n")
m_a <- report("umg_model(): eta -> y1 (fixed 1), eta -> y2 (lambda_2), person plate", {
  umg_model(
    nodes = list(
      umg_node("eta", "$\\eta_i$", observed = FALSE, dist = "N(0, psi)"),
      umg_node("y1", "$y_{1i}$", observed = TRUE),
      umg_node("y2", "$y_{2i}$", observed = TRUE)
    ),
    edges = list(
      umg_edge("eta", "y1", "dep", fixed = 1),
      umg_edge("eta", "y2", "dep", label = "$\\lambda_2$")
    ),
    plates = list(umg_plate("person", c("eta", "y1", "y2"),
                            "i = 1, ..., N"))
  )
})
report("umg_validate(m_a)", umg_validate(m_a))
cat("\nVertices:\n"); print(as.data.frame(m_a, what = "vertices"))
cat("\nEdges:\n");    print(as.data.frame(m_a, what = "edges"))
cat("\nIdentification snapshot (2 indicators: t-rule df must be negative):\n")
print(umg_identify(m_a))

#----- (b) Directed cycle --------------------------------------------------
cat("\n==================================================================\n")
cat("(b) Directed cycle: A -> B -> C -> A (all 'dep' edges)\n")
cat("==================================================================\n")
nodes_b <- list(
  umg_node("A", observed = TRUE, dist = "N(0, 1)"),
  umg_node("B", observed = TRUE),
  umg_node("C", observed = TRUE)
)
edges_b <- list(umg_edge("A", "B", "dep"),
                umg_edge("B", "C", "dep"),
                umg_edge("C", "A", "dep"))
report("umg_model() with validate = TRUE (default)",
       umg_model(nodes_b, edges_b,
                 list(umg_plate("person", c("A", "B", "C"), "i = 1, ..., N"))))
m_b <- umg_model(nodes_b, edges_b,
                 list(umg_plate("person", c("A", "B", "C"), "i = 1, ..., N")),
                 validate = FALSE)
cat("\n(constructed again with validate = FALSE to call umg_validate() explicitly)\n")
report("umg_validate(m_b)", umg_validate(m_b))

cat("\n(b') A two-vertex cycle through a mixing edge: c -> mu (mix), mu -> c (dep)\n")
nodes_b2 <- list(
  umg_node("pi", "$\\pi$", role = "par"),
  umg_node("c", "$c_i$", observed = FALSE, support = "categorical",
           dist = "Categorical(pi)"),
  umg_node("mu", "$\\mu$", role = "par")
)
edges_b2 <- list(umg_edge("pi", "c", "dep"),
                 umg_edge("c", "mu", "mix"),
                 umg_edge("mu", "c", "dep"))
report("umg_model(): cycle through mix + dep edges",
       umg_model(nodes_b2, edges_b2,
                 list(umg_plate("person", "c", "i = 1, ..., N"))))

#----- (c) Mixing edge from a continuous latent vertex ----------------------
cat("\n==================================================================\n")
cat("(c) Mixing edge whose source is a continuous latent vertex\n")
cat("==================================================================\n")
nodes_c <- list(
  umg_node("eta", "$\\eta_i$", observed = FALSE, dist = "N(0, 1)"),
  umg_node("mu0", "$\\mu_0^{(k)}$", role = "par"),
  umg_node("y", "$y_i$", observed = TRUE)
)
edges_c <- list(umg_edge("eta", "mu0", "mix"),
                umg_edge("mu0", "y", "dep"))
report("umg_model(): eta (latent, continuous) --mix--> mu0",
       umg_model(nodes_c, edges_c,
                 list(umg_plate("person", c("eta", "y"), "i = 1, ..., N"))))
m_c <- umg_model(nodes_c, edges_c,
                 list(umg_plate("person", c("eta", "y"), "i = 1, ..., N")),
                 validate = FALSE)
report("umg_validate(m_c)", umg_validate(m_c))

cat("\n(c') Mixing edge from an OBSERVED categorical vertex (also refused by W4)\n")
nodes_c2 <- list(
  umg_node("g", "$g_i$", observed = TRUE, support = "categorical",
           dist = "Categorical(pi)"),
  umg_node("mu0", "$\\mu_0^{(k)}$", role = "par"),
  umg_node("y", "$y_i$", observed = TRUE)
)
report("umg_model(): g (observed, categorical) --mix--> mu0",
       umg_model(nodes_c2, list(umg_edge("g", "mu0", "mix"),
                                umg_edge("mu0", "y", "dep")),
                 list(umg_plate("person", c("g", "y"), "i = 1, ..., N"))))

cat("\n(c'') Mixing edge from a latent categorical vertex that TARGETS an observed vertex\n")
nodes_c3 <- list(
  umg_node("c", "$c_i$", observed = FALSE, support = "categorical",
           dist = "Categorical(pi)"),
  umg_node("y", "$y_i$", observed = TRUE)
)
report("umg_model(): c (latent, categorical) --mix--> y (observed)",
       umg_model(nodes_c3, list(umg_edge("c", "y", "mix")),
                 list(umg_plate("person", c("c", "y"), "i = 1, ..., N"))))

cat("\n(c''') The well-formed counterpart: c (latent categorical) --mix--> mu0 (parameter)\n")
report("umg_model(): c --mix--> mu0 --dep--> y",
       umg_model(c(nodes_c3[1], list(umg_node("mu0", "$\\mu_0^{(k)}$", role = "par")),
                   nodes_c3[2]),
                 list(umg_edge("c", "mu0", "mix"), umg_edge("mu0", "y", "dep")),
                 list(umg_plate("person", c("c", "y"), "i = 1, ..., N"))))

#----- (d) Covariance edge joining a parameter vertex ------------------------
cat("\n==================================================================\n")
cat("(d) Covariance edge joining a parameter vertex\n")
cat("==================================================================\n")
nodes_d <- list(
  umg_node("eta", "$\\eta_i$", observed = FALSE, dist = "N(0, psi)"),
  umg_node("lambda", "$\\lambda$", role = "par"),
  umg_node("y1", "$y_{1i}$", observed = TRUE),
  umg_node("y2", "$y_{2i}$", observed = TRUE)
)
edges_d <- list(umg_edge("eta", "y1", "dep", fixed = 1),
                umg_edge("eta", "y2", "dep"),
                umg_edge("lambda", "y2", "dep"),
                umg_edge("eta", "lambda", "cov"))
report("umg_model(): eta <-> lambda (cov edge to a 'par' vertex)",
       umg_model(nodes_d, edges_d,
                 list(umg_plate("person", c("eta", "y1", "y2"), "i = 1, ..., N"))))
m_d <- umg_model(nodes_d, edges_d,
                 list(umg_plate("person", c("eta", "y1", "y2"), "i = 1, ..., N")),
                 validate = FALSE)
report("umg_validate(m_d)", umg_validate(m_d))

cat("\n(d') Covariance edge joining a constant vertex (also refused by W3)\n")
nodes_d2 <- list(
  umg_node("eta", "$\\eta_i$", observed = FALSE, dist = "N(0, psi)"),
  umg_node("one", "$1$", role = "const"),
  umg_node("y1", "$y_{1i}$", observed = TRUE)
)
report("umg_model(): eta <-> one (cov edge to a 'const' vertex)",
       umg_model(nodes_d2, list(umg_edge("eta", "y1", "dep", fixed = 1),
                                umg_edge("eta", "one", "cov")),
                 list(umg_plate("person", c("eta", "y1"), "i = 1, ..., N"))))

#----- (e) Edge crossing a plate boundary not licensed by the index ----------
cat("\n==================================================================\n")
cat("(e) Edge crossing a plate boundary that the index structure does not license\n")
cat("==================================================================\n")
cat("Case e1: crossed IRT plates. a_j lives in the item plate only, theta_i in\n",
    "the person plate only. The edge a_j -> theta_i would make a person-indexed\n",
    "vertex depend on an item-indexed vertex without the target being in the\n",
    "item plate (no index j on theta_i licenses it).\n", sep = "")
nodes_e1 <- list(
  umg_node("theta", "$\\theta_i$", observed = FALSE, dist = "N(0, 1)"),
  umg_node("u", "$u_{ij}$", observed = TRUE, support = "categorical",
           dist = "Bernoulli(p_ij)"),
  umg_node("a", "$a_j$", role = "par"),
  umg_node("b", "$b_j$", role = "par")
)
edges_e1 <- list(umg_edge("theta", "u", "dep"),
                 umg_edge("a", "u", "dep"),
                 umg_edge("b", "u", "dep"),
                 umg_edge("a", "theta", "dep"))   # <- unlicensed crossing
plates_e1 <- list(umg_plate("person", c("theta", "u"), "i = 1, ..., N"),
                  umg_plate("item", c("u", "a", "b"), "j = 1, ..., J"))
m_e1 <- report("umg_model(): a_j -> theta_i across crossed plates",
               umg_model(nodes_e1, edges_e1, plates_e1))
report("umg_validate(m_e1)", if (inherits(m_e1, "umg")) umg_validate(m_e1) else NULL)

cat("\nCase e2: nested plates (occasion t within person i). An edge from the\n",
    "occasion-level outcome y_ti to the person-level random intercept b0_i\n",
    "points from an inner-plate vertex to an outer-plate vertex; the outer\n",
    "vertex carries no t index, so the edge is not licensed.\n", sep = "")
nodes_e2 <- list(
  umg_node("y", "$y_{ti}$", observed = TRUE, dist = "N(mu_ti, sigma^2)"),
  umg_node("b0", "$\\beta_{0i}$", observed = FALSE),
  umg_node("g0", "$\\gamma_0$", role = "par")
)
edges_e2 <- list(umg_edge("g0", "b0", "dep"),
                 umg_edge("y", "b0", "dep"))     # <- inner -> outer
plates_e2 <- list(
  umg_plate("occasion", "y", "t = 1, ..., T_i", parent = "cluster"),
  umg_plate("cluster", c("y", "b0"), "i = 1, ..., N")
)
m_e2 <- report("umg_model(): y_ti -> b0_i (inner plate -> outer plate)",
               umg_model(nodes_e2, edges_e2, plates_e2))
report("umg_validate(m_e2)", if (inherits(m_e2, "umg")) umg_validate(m_e2) else NULL)

cat("\nCase e3: a vertex that is in a CHILD plate but not in its PARENT plate\n",
    "(plate membership inconsistent with nesting).\n", sep = "")
plates_e3 <- list(
  umg_plate("occasion", c("y", "b0"), "t = 1, ..., T_i", parent = "cluster"),
  umg_plate("cluster", "b0", "i = 1, ..., N")   # y missing from parent
)
m_e3 <- report("umg_model(): occasion plate member 'y' absent from parent 'cluster'",
               umg_model(nodes_e2, list(umg_edge("g0", "b0", "dep"),
                                        umg_edge("b0", "y", "dep")), plates_e3))
report("umg_validate(m_e3)", if (inherits(m_e3, "umg")) umg_validate(m_e3) else NULL)

cat("\nVerdict for (e): umg 0.5.0 checks plate COHERENCE (W5: members declared,\n",
    "parent declared, nesting acyclic) but implements no index-licensing rule\n",
    "for edges that cross plate boundaries; see the recorded outcomes above.\n",
    sep = "")

#----- Additional rules for completeness (W2, W5, W6, duplicates) ------------
cat("\n==================================================================\n")
cat("Additional checks: W2 (source annotation), W5 (plates), W6 (endpoints)\n")
cat("==================================================================\n")
report("W2: latent source vertex without a distribution annotation (advisory warning)",
       umg_model(list(umg_node("eta", observed = FALSE),
                      umg_node("y1", observed = TRUE),
                      umg_node("y2", observed = TRUE)),
                 list(umg_edge("eta", "y1", "dep", fixed = 1),
                      umg_edge("eta", "y2", "dep")),
                 list(umg_plate("person", c("eta", "y1", "y2"), "i = 1, ..., N"))))
report("W6: edge referencing an undeclared vertex",
       umg_model(list(umg_node("eta", observed = FALSE, dist = "N(0, 1)"),
                      umg_node("y1", observed = TRUE)),
                 list(umg_edge("eta", "y1", "dep", fixed = 1),
                      umg_edge("eta", "y9", "dep")),
                 list()))
report("W5: plate containing an undeclared vertex",
       umg_model(list(umg_node("eta", observed = FALSE, dist = "N(0, 1)"),
                      umg_node("y1", observed = TRUE)),
                 list(umg_edge("eta", "y1", "dep", fixed = 1)),
                 list(umg_plate("person", c("eta", "y1", "zz"), "i = 1, ..., N"))))
report("W5: plate declaring an unknown parent",
       umg_model(list(umg_node("eta", observed = FALSE, dist = "N(0, 1)"),
                      umg_node("y1", observed = TRUE)),
                 list(umg_edge("eta", "y1", "dep", fixed = 1)),
                 list(umg_plate("person", c("eta", "y1"), "i = 1, ..., N",
                                parent = "school"))))
report("W5: cyclic plate nesting (A parent B, B parent A)",
       umg_model(list(umg_node("eta", observed = FALSE, dist = "N(0, 1)"),
                      umg_node("y1", observed = TRUE)),
                 list(umg_edge("eta", "y1", "dep", fixed = 1)),
                 list(umg_plate("A", c("eta", "y1"), "i", parent = "B"),
                      umg_plate("B", c("eta", "y1"), "j", parent = "A"))))
report("Duplicate vertex names",
       umg_model(list(umg_node("y1", observed = TRUE, dist = "free"),
                      umg_node("y1", observed = TRUE, dist = "free")),
                 list(), list()))
report("umg_validate() on a non-umg object",
       umg_validate(list(nodes = list(), edges = list())))

cat("\nDone:", format(Sys.time()), "\n")
sink()
close(con)
